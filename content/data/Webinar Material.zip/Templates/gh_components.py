__author__ = "Christian Kongsgaard"
__license__ = "MIT"
__version__ = "0.1.0"

# -------------------------------------------------------------------------------------------------------------------- #
# Imports

# Module imports
import os

# Livestock imports
import livestock3d

# Grasshopper imports
import Grasshopper.Kernel as gh

# -------------------------------------------------------------------------------------------------------------------- #
# Grasshopper Component Class


class GHComponent:

    def __init__(self, ghenv):
        self.outputs = None
        self.inputs = None
        self.description = None
        self.name = 'Custom Generic Component'
        self.nick_name = 'CGC'
        self.message = 'This is a custom generic Grasshopper component.'
        self.category = '0 | Custom'
        self.subcategory = '0'
        self.gh_env = ghenv

    # COMPONENT STUFF
    def config_component(self):
        """
        Sets up the component, with the following steps:
        - Load component data
        - Generate component data
        - Generate outputs
        - Generate inputs
        """

        # Generate component data
        self.gh_env.Component.Name = self.name
        self.gh_env.Component.NickName = self.nick_name
        self.gh_env.Component.Message = self.message
        self.gh_env.Component.IconDisplayMode = self.gh_env.Component.IconDisplayMode.application
        self.gh_env.Component.Category = self.category
        self.gh_env.Component.SubCategory = self.subcategory
        self.gh_env.Component.Description = self.description

        # Generate outputs:
        for output_ in range(len(self.outputs)):
            self.add_output_parameter(output_)

        # Generate inputs:
        for input_ in range(len(self.inputs)):
            self.add_input_parameter(input_)

    def add_warning(self, warning):
        """
        Adds a Grasshopper warning to the component.
        :param warning: Warning text.
        """

        print(warning)
        w = gh.GH_RuntimeMessageLevel.Warning
        self.gh_env.Component.AddRuntimeMessage(w, warning)

    def add_output_parameter(self, output_):
        """
        Adds an output to the Grasshopper component.
        :param output_: Output index.
        """

        self.gh_env.Component.Params.Output[output_].NickName = self.outputs[output_]['name']
        self.gh_env.Component.Params.Output[output_].Name = self.outputs[output_]['name']
        self.gh_env.Component.Params.Output[output_].Description = self.outputs[output_]['description']

    def add_input_parameter(self, input_):
        """
        Adds an input to the Grasshopper component.
        :param input_: Input index.
        """

        # Set information
        self.gh_env.Component.Params.Input[input_].NickName = self.inputs[input_]['name']
        self.gh_env.Component.Params.Input[input_].Name = self.inputs[input_]['name']
        self.gh_env.Component.Params.Input[input_].Description = self.inputs[input_]['description']

        # Set type access
        if self.inputs[input_]['access'] == 'item':
            self.gh_env.Component.Params.Input[input_].Access = gh.GH_ParamAccess.item
        elif self.inputs[input_]['access'] == 'list':
            self.gh_env.Component.Params.Input[input_].Access = gh.GH_ParamAccess.list
        elif self.inputs[input_]['access'] == 'tree':
            self.gh_env.Component.Params.Input[input_].Access = gh.GH_ParamAccess.tree

    def add_default_value(self, parameter, param_number):
        """
        Adds a default value to a parameter.
        :param parameter: Parameter to add default value to
        :param param_number: Parameter number
        :return: Parameter
        """

        if not parameter:
            return self.inputs[param_number]['default_value']
        else:
            return parameter


class UTCICalculator(GHComponent):

    def __init__(self, ghenv):
        GHComponent.__init__(self, ghenv)

        def inputs():
            return {0: {'name': 'AirTemperature',
                        'description': 'Air temperature in C',
                        'access': 'list'},

                    1: {'name': 'MRTTemperature',
                        'description': 'Mean radiant temperature in C',
                        'access': 'list'},

                    2: {'name': 'RelativeHumidity',
                        'description': 'Relative Humidity in %',
                        'access': 'list'},

                    3: {'name': 'WindSpeed',
                        'description': 'Wind speed in m/s',
                        'access': 'list'},

                    4: {'name': 'Run',
                        'description': 'Run the Component',
                        'access': 'item'}}

        def outputs():
            return {0: {'name': 'readMe!',
                        'description': 'In case of any errors, it will be shown here.'},

                    1: {'name': 'UTCI',
                        'description': 'Calculated UTCI in C.'}}

        self.inputs = inputs()
        self.outputs = outputs()
        self.description = 'Computes the Universal Thermal Climate Index in C'
        self.name = 'Livestock UTCI Calculator'
        self.nick_name = 'UTCI Calculator'
        self.message = 'TGIC Webinar'

        self.air_temperature = None
        self.mrt_temperature = None
        self.relative_humidity = None
        self.wind_speed = None
        self.activate = False
        self.checks = False
        self.results = None

    def check_inputs(self):
        """
        Checks inputs and raises a warning if an input is not the correct type.
        """

        if isinstance(self.air_temperature, list):
            self.checks = True
        else:
            warning = 'Temperature should be a list of floats'
            self.add_warning(warning)

    def config(self):
        """
        Generates the Grasshopper component.
        """

        # Generate Component
        self.config_component()

    def run_checks(self, air_temp, mrt_temp, relhum, wind, run):
        """
        Gathers the inputs and checks them.
        :param temp: Outdoor temperature.
        """

        # Gather data
        self.air_temperature = air_temp
        self.mrt_temperature = mrt_temp
        self.relative_humidity = relhum
        self.wind_speed = wind
        self.activate = run

        # Run checks
        self.check_inputs()

    def utci(self):

        # Specify paths
        template_file = livestock3d.livestock_folder + '/utci_template.py'
        result_file = livestock3d.livestock_folder + '/utci_result.txt'

        # Run functions
        livestock3d.write_file(livestock3d.livestock_folder + '/temp_file.txt', self.air_temperature)
        livestock3d.write_file(livestock3d.livestock_folder + '/mrt_file.txt', self.mrt_temperature)
        livestock3d.write_file(livestock3d.livestock_folder + '/relhum_file.txt', self.relative_humidity)
        livestock3d.write_file(livestock3d.livestock_folder + '/wind_file.txt', self.wind_speed)

        livestock3d.write_template('utci', livestock3d.livestock_folder)
        livestock3d.run_template(livestock3d.get_python_exe(), template_file)

        utci_results = livestock3d.load_file(result_file)

        return utci_results

    def run(self):
        """
        In case all the checks have passed and run is True the component runs.
        It runs the utci() function.
        """

        if self.checks and self.activate:
            self.results = self.utci()


class UTCICalculatorSSH(GHComponent):

    def __init__(self, ghenv):
        GHComponent.__init__(self, ghenv)

        def inputs():
            return {0: {'name': 'AirTemperature',
                        'description': 'Air temperature in C',
                        'access': 'list'},
                    1: {'name': 'MRTTemperature',
                        'description': 'Mean radiant temperature in C',
                        'access': 'list'},
                    2: {'name': 'RelativeHumidity',
                        'description': 'Relative Humidity in %',
                        'access': 'list'},
                    3: {'name': 'WindSpeed',
                        'description': 'Wind speed in m/s',
                        'access': 'list'},
                    4: {'name': 'Run',
                        'description': 'Run the Component',
                        'access': 'item'}}

        def outputs():
            return {0: {'name': 'readMe!',
                        'description': 'In case of any errors, it will be shown here.'},
                    1: {'name': 'UTCI',
                        'description': 'Calculated UTCI in C.'}}

        self.inputs = inputs()
        self.outputs = outputs()
        self.description = 'Computes the Universal Thermal Climate Index in C through an SSH connection'
        self.name = 'Livestock SSH UTCI Calculator'
        self.nick_name = 'SSH UTCI Calculator'
        self.message = 'TGIC Webinar'

        self.air_temperature = None
        self.mrt_temperature = None
        self.relative_humidity = None
        self.wind_speed = None
        self.activate = False
        self.checks = False
        self.results = None

    def check_inputs(self):
        """
        Checks inputs and raises a warning if an input is not the correct type.
        """

        if isinstance(self.air_temperature, list):
            self.checks = True
        else:
            warning = 'Temperature should be a list of floats'
            self.add_warning(warning)

    def config(self):
        """
        Generates the Grasshopper component.
        """

        # Generate Component
        self.config_component()

    def run_checks(self, air_temp, mrt_temp, relhum, wind, run):
        """
        Gathers the inputs and checks them.
        :param temp: Outdoor temperature.
        """

        # Gather data
        self.air_temperature = air_temp
        self.mrt_temperature = mrt_temp
        self.relative_humidity = relhum
        self.wind_speed = wind
        self.activate = run

        # Run checks
        self.check_inputs()

    def utci(self):

        # Specify paths
        ssh_file = livestock3d.ssh_path + '/ssh_template.py'
        template_file = 'utci_template.py'
        result_file = 'utci_result.txt'
        air_temp_file = 'temp_file.txt'
        mrt_temp_file = 'mrt_file.txt'
        relhum_file = 'relhum_file.txt'
        wind_file = 'wind_file.txt'

        files_written = [air_temp_file, mrt_temp_file, relhum_file, wind_file, template_file]
        self.write_ssh_files(files_written)

        # Run functions
        livestock3d.write_file(livestock3d.ssh_path + '\\' + air_temp_file, self.air_temperature)
        livestock3d.write_file(livestock3d.ssh_path + '\\' + mrt_temp_file, self.mrt_temperature)
        livestock3d.write_file(livestock3d.ssh_path + '\\' + relhum_file, self.relative_humidity)
        livestock3d.write_file(livestock3d.ssh_path + '\\' + wind_file, self.wind_speed)

        livestock3d.run_template(livestock3d.get_python_exe(), ssh_file)

        utci_results = livestock3d.load_file(os.path.join(livestock3d.ssh_path, result_file))

        return utci_results

    def write_ssh_files(self, files_written_):
        # Clean SSH folder
        livestock3d.clean_ssh_folder()

        # SSH commands
        ssh_command = livestock3d.get_ssh()

        file_transfer = files_written_
        file_run = ['utci_template.py']
        file_return = ['utci_result.txt']

        ssh_command['file_transfer'] = ','.join(file_transfer) + ',utci_template.py'
        ssh_command['file_run'] = ','.join(file_run)
        ssh_command['file_return'] = ','.join(file_return)
        ssh_command['template'] = 'utci'

        livestock3d.write_ssh_commands(ssh_command)

        return ssh_command

    def run(self):
        """
        In case all the checks have passed and run is True the component runs.
        It runs the insulation_clothing() function.
        """

        if self.checks and self.activate:
            self.results = self.utci()
