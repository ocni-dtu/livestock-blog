__author__ = "Christian Kongsgaard"
__license__ = 'MIT'

# -------------------------------------------------------------------------------------------------------------------- #
# IMPORTS

import os
import scriptcontext as sc
import subprocess
import livestock3d


# ------------------------------------------------------------------------------#
# Variables


livestock_folder = r'C:/livestock3d/data'


# ------------------------------------------------------------------------------#
# Functions


def write_file(file_path, data):
    file = open(file_path, 'w')

    for line in data:
        file.write(str(line) + '\n')

    file.close()


def write_template(template, path):
    livestock3d.pick_template(template, path)


def run_template(py_exe, template_to_run):
    thread = subprocess.Popen([py_exe, template_to_run])
    thread.wait()
    thread.kill()


def load_file(file):
    file = open(file, 'r')
    lines = file.readlines()
    file.close()

    return lines


def get_python_exe():
    return str(sc.sticky["PythonExe"])


def check_output_folder(folder=livestock_folder):
    if not os.path.exists(folder):
        os.mkdir(folder)
