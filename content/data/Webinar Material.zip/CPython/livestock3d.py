__author__ = "Christian Kongsgaard"
__license__ = "MIT"

# -------------------------------------------------------------------------------------------------------------------- #
# Imports

# Module imports
import numpy as np
import matplotlib.pyplot as plt
import os

# Livestock imports
from utci_implementations import utci_numpy, utci_ladybug
# Grasshopper imports

# -------------------------------------------------------------------------------------------------------------------- #
# Livestock Functions


def my_function(folder):

    file = open(folder + '/data_file.txt', 'r')
    my_lines = [line.strip()
                for line in file.readlines()]
    file.close()

    repeat = int(my_lines[1].strip())
    line_to_write = my_lines[0].strip()

    result_file = open(folder + '/result.txt', 'w')

    for i in range(repeat):
        result_file.write(line_to_write + '\n')

    result_file.close()

    return None


def plot_graph():
    y_values = np.loadtxt('data_file.txt')
    x_values = np.linspace(0, len(y_values), len(y_values))

    plt.figure()
    plt.plot(x_values, y_values)
    plt.savefig('plot.png')

    return None


def utci():

    folder = os.path.dirname(os.path.realpath(__file__)) + '/data'

    air_temp = np.loadtxt(folder + '/temp_file.txt')
    mrt_temp = np.loadtxt(folder + '/mrt_file.txt')
    rel_hum = np.loadtxt(folder + '/relhum_file.txt')
    wind = np.loadtxt(folder + '/wind_file.txt')
    result_file = folder + '/utci_result.txt'

    utci = utci_numpy(air_temp, mrt_temp, wind, rel_hum)
    np.savetxt(result_file, utci)

    file = open(folder + '/out.txt', 'w')
    file.close()

def utci_lady():

    air_temp = np.loadtxt('air_temp.txt')
    mrt_temp = np.loadtxt('mrt_temp.txt')
    rel_hum = np.loadtxt('rh.txt')
    wind = np.loadtxt('wind.txt')
    result_file = 'result_ladybug.txt'

    utci = []
    for i in range(len(air_temp)):
        utci.append(utci_ladybug(air_temp[i], mrt_temp[i], wind[i], rel_hum[i]))

    np.savetxt(result_file, utci)

