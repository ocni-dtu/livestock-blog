# REQUIREMENTS:
	Rhino 5
	Grasshopper
	GHPython: https://www.food4rhino.com/app/ghpython
	Anaconda: https://docs.anaconda.com/anaconda/install/windows
		Needs an environment. How to do that see here and scroll down to "Conda Environment": https://ocni-dtu.github.io/install-livestock.html
	Ladybug Tools: https://www.food4rhino.com/app/ladybug-tools
	
	You can test the SSH connection on your Windows machine by installing Bash for Windows.
		Installation notes for that can be found here under "Livestock Ubuntu": https://ocni-dtu.github.io/install-livestock.html

# INSTALLATION:
Move the content of the folder "CPython" to: C:\livestock3d
Move the content of the folder "Livestock GH Components" to the Grasshopper UserObjects folder
Move the content of the folder "Templates" to %appdata%\McNeel\Rhinoceros\5.0\scripts\livestock3d

Restart Rhino

# FURTHER INFO:
More detailed information can be found at my blog: https://ocni-dtu.github.io/
If you find any bugs; create an issue on Github: https://github.com/livestock3d/livestock3d/issues